module AI.Project {

    requires javafx.graphics;
    requires javafx.fxml;
    requires javafx.controls;
    opens sample;
}